import { Button, Typography } from '@material-ui/core'
import React from 'react'
import styled from 'styled-components'

const PreviewContainer = styled.div`
    margin-left:auto;
    margin-right:auto;
    width: 200px;
    height:150px;
`

const StyledImg = styled.img`

`

function PhotoPreview({image}) {
    return (
        <>
            <Typography variant="subtitle1">
                Vista previa...
            </Typography>
            <PreviewContainer>
                <img style={{height: "100%", width: "100%"}} src={image}></img>
            </PreviewContainer>
            <Button variant="contained" color="secondary" component="span">
                            Subelo ya!
            </Button>
        </>
    )
}

export default PhotoPreview
