import { Button, Container, Grid, IconButton, Typography } from '@material-ui/core'
import { PhotoCamera } from '@material-ui/icons'
import React, { useState } from 'react'
import styled from 'styled-components'
import FotosList from '../components/FotosList'
import {} from 'path'
import PhotoPreview from '../components/PhotoPreview'

const StyledRoot = styled(Grid)`
    height: 100vh;
    width: 100%;
`

const StyledCanva = styled(Grid)`
    height: ${props => props.height || "initial"};
`

const TopContainer = styled(Container)`
    margin: 10px;
`


function Home() {

    const [imageUrl,setImageUrl] = useState("No has seleccionado ninguna foto")
    const [showPreview,setShowPreview] = useState(false)

    const getImage = event =>{
        if (event.target.files && event.target.files[0]) {
            /*let reader = new FileReader();
            reader.onload = (e) => {
            this.setState({image: e.target.result});
            };
            reader.readAsDataURL(event.target.files[0]);*/
            console.log(event.target.files[0])
            setImageUrl(URL.createObjectURL(event.target.files[0]))
            setShowPreview(true)
        }
    }

    return (
        <StyledRoot container justify="center" direction="row" alignItems="center">
            <StyledCanva item container xs={8} height={"100%"} direction="column">
                <TopContainer xs={2} style={{borderBottom: "1px solid black"}}>
                    <Typography variant="h4">
                        CloudEP
                    </Typography>
                    <Typography variant="subtitle1">
                        Hola, Usuario!
                    </Typography>
                </TopContainer>
                <Grid item container xs={10} spacing={4} direction="row" justify="space-evenly" style={{justifySelf:"center"}}>
                    <Grid item xs={9}>
                        <FotosList />
                    </Grid>
                    <Grid item xs={3}>
                        <Typography variant="h4">
                                ¡Comparte tu foto con los demás!
                        </Typography>
                        <input
                            accept="image/*"
                            style={{display:"none"}}
                            id="contained-button-file"
                            multiple
                            type="file"
                            onChange={(e) => getImage(e)}
                        />
                        <label htmlFor="contained-button-file">
                            <Button variant="contained" color="primary" component="span" style={{marginBottom:"20px"}}>
                            Elige una foto
                            </Button>
                        </label>
                        { showPreview && <PhotoPreview image={imageUrl}/> }
                    </Grid>
                </Grid>
            </StyledCanva>
        </StyledRoot>
    )
}

export default Home
